package com.dnsswitch.dns

import com.dnsswitch.config.OdohConfig
import odohclient.Odohclient
import odohclient.QueryContext
import odohclient.Session
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * ODoH channel (RFC 9230).
 *
 * TLS is handled by OkHttp; HPKE and ODoH wire format by the Go mobile bridge.
 *
 * Instances MUST be reused across queries (see DnsResolver): the Target's ODoH config
 * is cached here, and a new instance per query would re-download it every time.
 */
class OdohChannel(
    private val cfg: OdohConfig,
    baseClient: OkHttpClient
) : DnsChannel {

    /**
     * When the config lists proxy IPs, the Proxy host name is never sent to a resolver: OkHttp
     * connects to those addresses directly (TLS still validates the Proxy host name).
     */
    private val client: OkHttpClient =
        if (cfg.proxyIps.isEmpty() || cfg.proxyHost.isEmpty()) baseClient
        else baseClient.newBuilder().dns(PinnedDns(cfg.proxyHost, cfg.proxyIps, baseClient.dns)).build()

    override val type = ChannelType.ODOH
    override val defaultTimeoutMs = 3500L

    /** Most recent failure reason (null after a successful query); surfaced in tests and logs. */
    @Volatile
    var lastError: String? = null
        private set

    private val stateLock = Any()
    private val fetchLock = ReentrantLock()
    private var session: Session? = null
    private var sessionFetchedAt = 0L

    /** Config lifetime: the Target's Cache-Control max-age when present, else [CONFIG_TTL_MS]. */
    @Volatile
    private var configTtlMs = CONFIG_TTL_MS
    private var retryAfter = 0L
    private var lastForcedRefresh = 0L

    /** Result of one encrypt → proxy → decrypt round trip. */
    private sealed class Outcome {
        class Answer(val bytes: ByteArray) : Outcome()
        /** Target did not accept our key (HTTP 401 / empty body): the cached config is stale. */
        class KeyMismatch(val reason: String) : Outcome()
        class Failure(val reason: String) : Outcome()
    }

    /** Index of the advertised config that the Target last accepted. */
    @Volatile
    private var keyIndex = 0

    override fun query(query: ByteArray, timeoutMs: Long): ByteArray? {
        var sess = ensureSession() ?: return null
        var count = sess.count().toInt().coerceAtLeast(1)
        var index = keyIndex.coerceIn(0, count - 1)
        var tried = 0
        var refreshed = false
        while (true) {
            when (val r = exchange(sess, index, query, timeoutMs)) {
                is Outcome.Answer -> {
                    keyIndex = index
                    lastError = null
                    return r.bytes
                }
                is Outcome.Failure -> return fail(r.reason)
                is Outcome.KeyMismatch -> {
                    // The Target may advertise several keys: try the others before refetching.
                    tried++
                    if (tried < count) {
                        index = (index + 1) % count
                        continue
                    }
                    // RFC 9230: unknown key id means the config was rotated or is stale.
                    // Refetch the config once and start over.
                    if (refreshed || !allowForcedRefresh()) {
                        return fail(r.reason + "（已尝试 Target 公布的全部 $count 个密钥并刷新配置，仍被拒绝）")
                    }
                    refreshed = true
                    invalidateSession()
                    sess = ensureSession() ?: return null
                    count = sess.count().toInt().coerceAtLeast(1)
                    index = 0
                    keyIndex = 0
                    tried = 0
                }
            }
        }
    }

    private fun exchange(sess: Session, index: Int, query: ByteArray, timeoutMs: Long): Outcome {
        val qctx: QueryContext = try {
            sess.encryptQueryAt(query, index.toLong())
        } catch (e: Exception) {
            return Outcome.Failure("加密查询失败：" + describe(e))
        }
        val messageBytes = qctx.message()
        if (messageBytes.isEmpty()) return Outcome.Failure("加密后的消息为空")

        val req = try {
            Request.Builder()
                .url(cfg.effectiveProxyUrl)
                .post(messageBytes.toRequestBody(ODOH_MEDIA))
                .header("Content-Type", ODOH_MEDIA_VALUE)
                .header("Accept", ODOH_MEDIA_VALUE)
                // RethinkDNS sends an empty User-Agent: the relay learns nothing about the client app.
                .header("User-Agent", "")
                .build()
        } catch (e: IllegalArgumentException) {
            return Outcome.Failure("Proxy URL 无效")
        }

        val bounded = client.newBuilder()
            .callTimeout(timeoutMs.coerceIn(500, 10000), TimeUnit.MILLISECONDS)
            .build()
        val respBytes = try {
            bounded.newCall(req).execute().use { resp ->
                if (resp.code == 401 || (resp.code == 400 && bodyMentionsKey(resp))) {
                    // 401 is what RFC 9230 specifies; some Targets answer 400 "unknown key id".
                    return Outcome.KeyMismatch("Target 拒绝了密钥：" + diag(resp))
                }
                if (!resp.isSuccessful) return Outcome.Failure("Proxy 返回 " + diag(resp))
                resp.body?.bytes()
            }
        } catch (e: Exception) {
            return Outcome.Failure("连接 Proxy 失败：" + describe(e))
        }
        // Some proxies relay the Target's 401 as an empty 200 response.
        if (respBytes == null || respBytes.isEmpty()) {
            return Outcome.KeyMismatch("Proxy 返回空响应（可能是 Target 拒绝了密钥）")
        }

        val answer = try {
            qctx.decryptResponse(respBytes)
        } catch (e: Exception) {
            return Outcome.KeyMismatch("解密响应失败：" + describe(e))
        }
        if (answer == null || answer.size < 12) return Outcome.Failure("解密后的 DNS 报文无效")
        return Outcome.Answer(answer)
    }

    /** Limits forced config refreshes to one per [FORCED_REFRESH_INTERVAL_MS]. */
    private fun allowForcedRefresh(): Boolean = synchronized(stateLock) {
        val now = System.currentTimeMillis()
        if (now - lastForcedRefresh < FORCED_REFRESH_INTERVAL_MS) {
            false
        } else {
            lastForcedRefresh = now
            true
        }
    }

    /**
     * Returns a usable session, fetching the Target config at most once at a time.
     * After a failed fetch, further queries fail fast for [FAILURE_BACKOFF_MS] instead of each
     * blocking on its own timeout (which used to serialise all DNS queries behind the lock).
     * A previously fetched session is kept as a fallback while refresh is failing.
     */
    private fun ensureSession(): Session? {
        synchronized(stateLock) {
            val now = System.currentTimeMillis()
            val s = session
            if (s != null && now < sessionFetchedAt + configTtlMs) return s
            if (now < retryAfter) return s
        }
        fetchLock.withLock {
            synchronized(stateLock) {
                // Another thread may have finished the fetch while we waited for the lock.
                val now = System.currentTimeMillis()
                val s = session
                if (s != null && now < sessionFetchedAt + configTtlMs) return s
                if (now < retryAfter) return s
            }
            val fresh = fetchSession()
            synchronized(stateLock) {
                val now = System.currentTimeMillis()
                if (fresh != null) {
                    session = fresh
                    sessionFetchedAt = now
                    retryAfter = 0L
                } else {
                    retryAfter = now + FAILURE_BACKOFF_MS
                }
                return session
            }
        }
    }

    private fun fetchSession(): Session? {
        val target = cfg.effectiveTargetUrl
        if (target.isEmpty()) {
            report("Target URL 无效（必须是 https:// 开头）")
            return null
        }
        val req = try {
            Request.Builder().url("$target/.well-known/odohconfigs").header("User-Agent", "").get().build()
        } catch (e: IllegalArgumentException) {
            report("Target URL 无效")
            return null
        }
        val bounded = client.newBuilder()
            .callTimeout(CONFIG_FETCH_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .build()
        val bytes = try {
            bounded.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    report("获取 Target 配置失败：" + diag(resp))
                    return null
                }
                configTtlMs = ttlFrom(resp.header("Cache-Control"))
                resp.body?.bytes()
            }
        } catch (e: Exception) {
            report("获取 Target 配置失败：" + describe(e))
            return null
        }
        if (bytes == null || bytes.isEmpty()) {
            report("Target 配置为空")
            return null
        }
        return try {
            Odohclient.newSession(bytes)
        } catch (e: Exception) {
            report("解析 Target 配置失败：" + describe(e))
            null
        }
    }

    private fun ttlFrom(cacheControl: String?): Long {
        val secs = cacheControl?.let { Regex("max-age=(\\d+)", RegexOption.IGNORE_CASE).find(it) }
            ?.groupValues?.get(1)?.toLongOrNull() ?: return CONFIG_TTL_MS
        return (secs * 1000L).coerceIn(MIN_CONFIG_TTL_MS, MAX_CONFIG_TTL_MS)
    }

    private fun invalidateSession() {
        synchronized(stateLock) {
            session = null
            sessionFetchedAt = 0L
            retryAfter = 0L
        }
    }

    private fun fail(msg: String): ByteArray? {
        report(msg)
        return null
    }

    /** Remember the error and write it to the log page once per distinct message. */
    private fun report(msg: String) {
        val changed = lastError != msg
        lastError = msg
        if (changed) DnsStats.system("ODoH：$msg")
    }

    private fun bodyMentionsKey(resp: okhttp3.Response): Boolean =
        runCatching { resp.peekBody(256).string().contains("key", ignoreCase = true) }.getOrDefault(false)

    /** HTTP status plus the headers/body that identify WHO rejected the request (e.g. 401). */
    private fun diag(resp: okhttp3.Response): String {
        val hdrs = listOf("Location", "WWW-Authenticate", "Proxy-Status", "Server", "CF-Ray")
            .mapNotNull { n -> resp.header(n)?.let { "$n=$it" } }
        val ct = resp.body?.contentType()
        val textual = ct != null && (ct.type == "text" || ct.subtype.contains("json"))
        val body = if (textual) {
            runCatching { resp.peekBody(200).string().replace(Regex("\\s+"), " ").trim() }.getOrDefault("")
        } else ""
        return "HTTP ${resp.code}" +
            (if (hdrs.isNotEmpty()) " [" + hdrs.joinToString("; ") + "]" else "") +
            (if (body.isNotEmpty()) " $body" else "")
    }

    private fun describe(e: Exception): String =
        e.javaClass.simpleName + (e.message?.let { ": $it" } ?: "")

    companion object {
        private const val CONFIG_TTL_MS = 5 * 60 * 1000L
        private const val MIN_CONFIG_TTL_MS = 60 * 1000L
        private const val MAX_CONFIG_TTL_MS = 60 * 60 * 1000L
        private const val FAILURE_BACKOFF_MS = 10_000L
        private const val FORCED_REFRESH_INTERVAL_MS = 10_000L
        private const val CONFIG_FETCH_TIMEOUT_MS = 4000L
        private const val ODOH_MEDIA_VALUE = "application/oblivious-dns-message"
        private val ODOH_MEDIA = ODOH_MEDIA_VALUE.toMediaType()
    }
}

/** Resolves [host] to fixed [ips] and defers every other name to [delegate]. */
internal class PinnedDns(
    private val host: String,
    ips: List<String>,
    private val delegate: Dns
) : Dns {
    private val addrs: List<InetAddress> =
        ips.mapNotNull { runCatching { InetAddress.getByName(it) }.getOrNull() }

    override fun lookup(hostname: String): List<InetAddress> =
        if (addrs.isNotEmpty() && hostname.equals(host, ignoreCase = true)) addrs
        else delegate.lookup(hostname)
}
